import { delay } from "@whiskeysockets/baileys";
import chalk from "chalk";

const activeGames = new Map();
let isListenerAttached = false;

// أبقيت الاسم NovaUltra هنا لكي يتعرف عليه نظام البوت الخاص بك ولا يعطيك unknown command
const NovaUltra = {
    command: "اكس",
    description: "لعبة XO الكلاسيكية",
    usage: ".اكس [@منشن | بوت]",
    elite: "off",
    group: true,
    prv: false,
    lock: "off",
    category: "games"
};

const getIdType = (id) => {
    if (!id) return "Unknown";
    if (id.includes("@lid")) return "LID (Hash)";
    if (id.includes("@s.whatsapp.net")) return "JID (Phone)";
    return "Unknown";
};

const normalizeJID = (jid) => {
    if (!jid) return "";
    let clean = jid.split(':')[0];
    if (clean.includes('@lid')) return clean;
    return clean.includes('@s.whatsapp.net') ? clean : `${clean}@s.whatsapp.net`;
};

function logMove(chatId, incomingID, playerObj, move, status, reason = "") {
    console.log(chalk.gray("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    console.log(chalk.yellow.bold(`🎮 XO GAME ACTION [${chatId.split('@')[0]}]`));
    console.log(chalk.gray("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    if (status === "SUCCESS") {
        console.log(chalk.bgGreen.black(` ✅ STATUS: VALID MOVE `));
    } else {
        console.log(chalk.bgRed.white(` ❌ STATUS: REJECTED `) + ` (${reason})`);
    }
    console.log(chalk.gray("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"));
}

class TicTacToe {
    constructor(p1Data, p2Data) {
        this.board = Array(9).fill(null);
        this.playersData = {
            '❎': { ...p1Data, mark: '❎' },
            '⭕': { ...p2Data, mark: '⭕' }
        };
        this.turn = '❎';
        this.winner = null;
    }
    isTurn(incomingID) {
        const currentPlayer = this.playersData[this.turn];
        const normalizedIncoming = normalizeJID(incomingID);
        return currentPlayer.pn === normalizedIncoming || (currentPlayer.lid && currentPlayer.lid === normalizedIncoming);
    }
    identifyPlayer(incomingID) {
        const normalizedIncoming = normalizeJID(incomingID);
        if (this.playersData['❎'].pn === normalizedIncoming || (this.playersData['❎'].lid && this.playersData['❎'].lid === normalizedIncoming)) return this.playersData['❎'];
        if (this.playersData['⭕'].pn === normalizedIncoming || (this.playersData['⭕'].lid && this.playersData['⭕'].lid === normalizedIncoming)) return this.playersData['⭕'];
        return null;
    }
    play(index) {
        if (this.winner || this.board[index]) return false;
        this.board[index] = this.turn;
        this.checkWinner();
        this.turn = this.turn === '❎' ? '⭕' : '❎';
        return true;
    }
    checkWinner() {
        const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
        for (const [a, b, c] of wins) {
            if (this.board[a] && this.board[a] === this.board[b] && this.board[a] === this.board[c]) {
                this.winner = this.board[a];
                return;
            }
        }
        if (this.board.every(cell => cell !== null)) this.winner = 'draw';
    }
    botMove() {
        const available = this.board.map((v, i) => v ? null : i).filter(i => i !== null);
        if (available.length === 0) return;
        this.play(available[Math.floor(Math.random() * available.length)]);
    }
}

async function sendBoard(sock, jid, game, quotedMsg) {
    const nums = {1:'1️⃣',2:'2️⃣',3:'3️⃣',4:'4️⃣',5:'5️⃣',6:'6️⃣',7:'7️⃣',8:'8️⃣',9:'9️⃣'};
    const map = game.board.map((v, i) => v ? v : nums[i + 1]);
    const p1Raw = normalizeJID(game.playersData['❎'].pn);
    const p2Raw = game.playersData['⭕'].pn === 'BOT' ? 'BOT' : normalizeJID(game.playersData['⭕'].pn);
    
    // التعديل هنا: يظهر الاسم XO فقط
    let text = `🎮 *XO*\n\n`;
    text += `❎ : @${p1Raw.split('@')[0]}\n`;
    text += `⭕ : ${p2Raw === 'BOT' ? '🤖 البوت' : '@' + p2Raw.split('@')[0]}\n\n`;
    text += `${map[0]} ${map[1]} ${map[2]}\n${map[3]} ${map[4]} ${map[5]}\n${map[6]} ${map[7]} ${map[8]}\n\n`;
    
    if (game.winner) {
        if (game.winner === 'draw') text += `🤝 *تعادل!*`;
        else text += `🏆 *الفائز:* ${game.playersData[game.winner].pn === 'BOT' ? '🤖 البوت' : '@' + normalizeJID(game.playersData[game.winner].pn).split('@')[0]}`;
        activeGames.delete(jid);
    } else {
        text += `⏳ الدور: ${game.playersData[game.turn].pn === 'BOT' ? '🤖 البوت' : '@' + normalizeJID(game.playersData[game.turn].pn).split('@')[0]}\n`;
    }
    const mentions = [p1Raw, p2Raw].filter(id => id !== 'BOT' && id !== null);
    await sock.sendMessage(jid, { text, mentions }, { quoted: quotedMsg });
}

function attachGameListener(sock) {
    if (isListenerAttached) return;
    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message) return;
        const chatId = msg.key.remoteJid;
        const game = activeGames.get(chatId);
        if (!game) return;
        const body = (msg.message?.conversation || msg.message?.extendedTextMessage?.text || "").trim();
        let senderID = normalizeJID(msg.key.participant || msg.key.remoteJid);
        
        if (body === "اكس الغاء") {
            activeGames.delete(chatId);
            await sock.sendMessage(chatId, { text: "🛑 تم إنهاء اللعبة." });
            return;
        }
        
        if (!/^[1-9]$/.test(body)) return;
        const move = parseInt(body) - 1;
        const identifiedPlayer = game.identifyPlayer(senderID);
        
        if (identifiedPlayer && game.isTurn(senderID)) {
            if (game.play(move)) {
                await sendBoard(sock, chatId, game, msg);
                if (!game.winner && game.playersData[game.turn].pn === "BOT") {
                    await delay(1000);
                    game.botMove();
                    await sendBoard(sock, chatId, game, msg);
                }
            }
        }
    });
    isListenerAttached = true;
}

async function execute({ sock, msg, args, sender }) {
    attachGameListener(sock);
    const jid = msg.chat;
    if (activeGames.has(jid)) return sock.sendMessage(jid, { text: "⚠ توجد لعبة جارية!" }, { quoted: msg });
    
    const p1Data = { pn: normalizeJID(sender.pn), lid: sender.lid ? normalizeJID(sender.lid) : null };
    let p2Data = null;
    
    if (args[0] === "بوت") p2Data = { pn: "BOT", lid: "BOT" };
    else {
        const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (mentioned) p2Data = { pn: normalizeJID(mentioned), lid: null };
    }
    
    if (!p2Data) return sock.sendMessage(jid, { text: "📌 استخدم: .اكس @منشن أو .اكس بوت" }, { quoted: msg });
    
    const newGame = new TicTacToe(p1Data, p2Data);
    activeGames.set(jid, newGame);
    await sendBoard(sock, jid, newGame, msg);
}

export default { NovaUltra, execute };