import fs from "fs";
import path from "path";
import axios from "axios";
import { generateWAMessageFromContent } from "@whiskeysockets/baileys";

const NovaUltra = {
  command: "شعر",
  description: "جلب أبيات شعرية من موقع الديوان",
  nova: "on"
};

const fallbackPoems = [
  { t: "وإذا أتتك مذمتي من ناقصٍ... فهي الشهادة لي بأني كاملُ", a: "المتنبي" },
  { t: "على قدر أهل العزم تأتي العزائمُ... وتأتي على قدر الكرام المكارمُ", a: "المتنبي" },
  { t: "وما نيل المطالب بالتمني... ولكن تؤخذ الدنيا غلاباً", a: "أحمد شوقي" }
];

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function sendFancyText(sock, jid, text, quotedMsg) {
  let imageBuffer = null;

  try {
    const imagePath = path.join(process.cwd(), "nova", "image2.jpeg");
    imageBuffer = fs.readFileSync(imagePath);
  } catch (e) {
    imageBuffer = null;
  }

  const contextInfo = {
    externalAdReply: {
      title: "𝐵𝑂𝐽𝐴𝐶𝐾 𝐿𝐼𝑇𝐸𝑅𝐴𝑇𝑈𝑅𝐸",
      body: "𝐾𝐿𝐴𝑈𝑆 𝑃𝑂𝐸𝑇𝑅𝑌 𝐸𝑁𝐺𝐼𝑁𝐸",
      mediaType: 1,
      renderLargerThumbnail: true,
      thumbnail: imageBuffer || undefined,
      showAdAttribution: true
    }
  };

  const msg = generateWAMessageFromContent(
    jid,
    {
      extendedTextMessage: {
        text,
        contextInfo
      }
    },
    {
      userJid: sock.user?.id,
      quoted: quotedMsg
    }
  );

  return sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
}

async function getPoemFromDiwan() {
  try {
    // هذا endpoint غير رسمي (scrape خفيف)
    const res = await axios.get("https://www.aldiwan.net/randompoem.html", {
      timeout: 10000,
      headers: {
        "User-Agent": "Mozilla/5.0"
      }
    });

    const html = res.data;

    const textMatch = html.match(/<div class="bet-1">(.*?)<\/div>/g);
    const authorMatch = html.match(/<a href="\/cat-poet-.*?">(.*?)<\/a>/);

    if (textMatch && textMatch.length > 0) {
      const poemText = textMatch
        .map(line => line.replace(/<.*?>/g, "").trim())
        .join("\n");

      const author = authorMatch ? authorMatch[1] : "غير معروف";

      return {
        text: poemText,
        author,
        source: "موقع الديوان"
      };
    }

    return null;
  } catch {
    return null;
  }
}

async function execute({ sock, msg }) {
  const chatId = msg.key.remoteJid;

  try {
    await sendFancyText(sock, chatId, "⏳ جاري جلب القصيدة من الديوان...", msg);

    let poem = await getPoemFromDiwan();

    if (!poem) {
      const fb = pickRandom(fallbackPoems);
      poem = {
        text: fb.t,
        author: fb.a,
        source: "الأرشيف الداخلي"
      };
    }

    const report =
      `📜 *مقتبس شعري:*\n\n` +
      `${poem.text}\n\n` +
      `👤 *الشاعر:* ${poem.author}\n` +
      `🔗 *المصدر:* ${poem.source}`;

    await sendFancyText(sock, chatId, report, msg);

  } catch (error) {
    await sock.sendMessage(chatId, {
      text: "⚠️ تعذر جلب القصيدة حالياً."
    }, { quoted: msg });
  }
}

export default { NovaUltra, execute };