import { generateWAMessageFromContent } from "@whiskeysockets/baileys";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { jidDecode } from "@whiskeysockets/baileys";
import { getPlugins } from "../../handlers/plugins.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const activeMenuSessions = new Map();

const KlausBoJack = {
  command: "اوامر", 
  description: "قائمة التحكم والأوامر — 𝐾𝐿𝐴𝑈𝑆",
  elite: "off",
  lock: "off",
  nova: "on"
};

function decode(jid) {
  return (jidDecode(jid)?.user || jid.split("@")[0]) + "@s.whatsapp.net";
}

function getCommandStatusSuffix(plugin) {
  let suffix = "";
  const isElite = plugin.elite === "on";
  const isLocked = plugin.lock === "on";
  
  const adminKeywords = ["طرد", "حظر", "رفع", "خفض", "تغيير", "قفل", "فتح", "kick", "ban", "promote", "demote", "admin", "group", "tagall", "hidetag"];

  const cmdArray = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
  const textToCheck = ((plugin.description || "") + " " + cmdArray.join(" ")).toLowerCase();
  const isAdminRelated = adminKeywords.some(k => textToCheck.includes(k)) || plugin.admin === true || plugin.group === true;

  if (isLocked) suffix += " 🔐";
  if (isElite) suffix += " ⭐";
  if (!isLocked && !isElite && isAdminRelated) suffix += " 🛡️";

  return suffix; 
}

async function execute({ sock, msg, args }) {
    // --- KLAUS INJECTION SYSTEM ---
    const _nova_origSend = sock.sendMessage;
    sock.sendMessage = async (jid, content, options = {}) => {
        if (typeof KlausBoJack !== 'undefined' && KlausBoJack.nova === 'on') {
            const _textBody = content.text || content.caption;
            if (_textBody && typeof _textBody === 'string') {
                let _nD = { ceiling: "𝐾𝐿𝐴𝑈𝑆", name: "𝐵𝑂𝐽𝐴𝐶𝐾", description: "𝐻𝐸𝐿𝐿𝑂 𝑀𝐴𝑆𝑇𝐸𝑅.. ", verification: true, media: true };
                try {
                    const _cfgPath = path.join(process.cwd(), "nova", "config.js");
                    const _cfgContent = fs.readFileSync(_cfgPath, "utf8");
                    const _match = _cfgContent.match(/novaInfo:\s*({[\s\S]*?})(,|$)/);
                    if (_match) {
                        const _loaded = new Function("return " + _match[1])();
                        _nD = { ..._nD, ..._loaded };
                    }
                } catch(e) {}

                let _nTh = null;
                const _isMediaActive = (_nD.media !== false); 
                if (_isMediaActive) {
                    try {
                        const _img = path.join(process.cwd(), "nova", "image1.jpeg");
                        if (fs.existsSync(_img)) _nTh = fs.readFileSync(_img);
                    } catch(e) {}
                }

                let _finalQuoted = options.quoted || msg;
                if (_nD.verification === true) {
                    _finalQuoted = {
                        key: { fromMe: false, participant: "0@s.whatsapp.net", remoteJid: "0@s.whatsapp.net" },
                        message: { conversation: _nD.ceiling || "" }
                    };
                }

                const _contextInfo = {
                    mentionedJid: options.mentions || [],
                    stanzaId: "KLAUS_" + Date.now(),
                    ...(_nD.verification ? { participant: "0@s.whatsapp.net" } : {}),
                    quotedMessage: _finalQuoted.message,
                    externalAdReply: (_isMediaActive) ? {
                        title: _nD.name, 
                        body: _nD.description, 
                        mediaType: 1, 
                        renderLargerThumbnail: true, 
                        showAdAttribution: true, 
                        ...(_nTh ? { thumbnail: _nTh } : {})
                    } : null
                };

                const _nM = generateWAMessageFromContent(jid, {
                    extendedTextMessage: { text: _textBody, contextInfo: _contextInfo }
                }, { userJid: sock.user?.id, quoted: _finalQuoted, linkPreview: _isMediaActive ? undefined : null });

                return await sock.relayMessage(jid, _nM.message, { messageId: _nM.key.id });
            }
        }
        return await _nova_origSend.call(sock, jid, content, options);
    };

  const chatId = msg.key.remoteJid;
  const sender = decode(msg.key.participant || chatId);

  if (activeMenuSessions.has(chatId)) {
      const oldSession = activeMenuSessions.get(chatId);
      sock.ev.off("messages.upsert", oldSession.listener);
      clearTimeout(oldSession.timer);
      activeMenuSessions.delete(chatId);
  }

  try {
    const pluginsRoot = path.join(process.cwd(), "plugins");
    const categories = fs
      .readdirSync(pluginsRoot)
      .filter((dir) => fs.statSync(path.join(pluginsRoot, dir)).isDirectory());

    const getMainMenuText = () => {
      const allPlugins = getPlugins();
      let totalCmds = 0, eliteCmds = 0, lockedCmds = 0, unsafeCmds = 0;
      const adminKeywords = ["طرد", "حظر", "رفع", "خفض", "تغيير", "قفل", "فتح", "kick", "ban", "promote", "demote", "admin", "group", "tagall", "hidetag"];

      for (const plugin of Object.values(allPlugins)) {
        if (!plugin || plugin.hidden) continue;
        totalCmds++;
        const isElite = plugin.elite === "on", isLocked = plugin.lock === "on";
        if (isElite) eliteCmds++;
        if (isLocked) lockedCmds++;
        const cmdArray = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
        const textToCheck = ((plugin.description || "") + " " + cmdArray.join(" ")).toLowerCase();
        const isAdminRelated = adminKeywords.some(k => textToCheck.includes(k)) || plugin.admin === true || plugin.group === true;
        if (!isLocked && !isElite && isAdminRelated) unsafeCmds++;
      }

      // --- الهيكلة الجديدة للمنيو الرئيسي ---
      let menu = `
╭━━━〔 𝐵𝑂𝐽𝐴𝐶𝐾 〕━━━╮

      *𝑇𝐻𝐸 𝐶𝑂𝑀𝑀𝐴𝑁𝐷𝑆*
   
🦎 *𝑇𝑂𝑂𝐿𝑆:*
`;
      for (const c of categories) {
        menu += `  ◈──『 *${c}* 』\n`;
      }
      menu += `
🛜 *𝑆𝑌𝑆𝑇𝐸𝑀 𝐴𝑁𝐴𝐿𝑌𝑍𝐸:*
┌─ 👌🏿 𝑇𝑂𝑂𝐿𝑆: ${totalCmds}
├─ ⭐ 𝐸𝐿𝐼𝑇𝐸: ${eliteCmds}


🇷🇺🖐🏿 Да здравствуют Советы! 
──────────────────
     
╰━━━━━━━━━━━━━━━╯
`;
      return menu;
    };

    const initialText = getMainMenuText();
    const sentMsg = await sock.sendMessage(chatId, { text: initialText }, { quoted: msg });
    const botMsgKey = sentMsg.key;

    let state = "MAIN"; 
    let sessionTimer; 

    const updateMessage = async (newText) => {
      await sock.sendMessage(chatId, { text: newText, edit: botMsgKey });
    };

    const listener = async ({ messages }) => {
      const newMsg = messages[0];
      if (!newMsg.message || newMsg.key.remoteJid !== chatId) return;
      const newSender = decode(newMsg.key.participant || newMsg.key.remoteJid);
      if (newSender !== sender) return; 

      const text = newMsg.message?.conversation || newMsg.message?.extendedTextMessage?.text || "";
      if (!text) return;
      const input = text.trim(); 

      if (input === "رجوع") {
        if (state === "CATEGORY_VIEW") {
          await sock.sendMessage(chatId, { react: { text: "🔙", key: newMsg.key } });
          await updateMessage(getMainMenuText());
          state = "MAIN";
          resetTimer();
        }
        return;
      }

      if (state === "MAIN") {
        const selectedCategory = categories.find(c => c.toLowerCase() === input.toLowerCase());
        if (selectedCategory) {
          await sock.sendMessage(chatId, { react: { text: "📂", key: newMsg.key } });
          const plugins = getPlugins();
          const commandsList = [];

          for (const plugin of Object.values(plugins)) {
            if (!plugin || plugin.hidden) continue;
            const pluginPath = plugin.filePath || "";
            if (pluginPath.includes(`/plugins/${selectedCategory}/`)) {
              const cmds = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
              const suffix = getCommandStatusSuffix(plugin);
              commandsList.push(`  » \`${cmds[0]}\` ${suffix}\n    └─ ${plugin.description || 'لا يوجد وصف'}`);
            }
          }

          // --- هيكلة قائمة الأوامر الفرعية ---
          let categoryMenu = `
╭━━〔 *${selectedCategory.toUpperCase()}* 〕━━╮
\n`;
          categoryMenu += commandsList.length ? commandsList.join("\n\n") : "  ⚠️ لا توجد أوامر حالياً.";
          categoryMenu += `
\n──────────────────
↩️ أرسل *'رجوع'* للعودة.
      *${'𝐵𝑂𝐽𝐴𝐶𝐾'}*
╰━━━━━━━━━━━━━━━╯`;

          await updateMessage(categoryMenu);
          state = "CATEGORY_VIEW";
          resetTimer();
        } 
      }
    };

    const resetTimer = () => {
      if (sessionTimer) clearTimeout(sessionTimer);
      sessionTimer = setTimeout(() => {
        sock.ev.off("messages.upsert", listener);
        activeMenuSessions.delete(chatId);
      }, 3 * 60 * 1000); 
      activeMenuSessions.set(chatId, { listener, timer: sessionTimer });
    };

    resetTimer();
    sock.ev.on("messages.upsert", listener);

  } catch (err) {
    console.error("Menu Error:", err);
    await sock.sendMessage(chatId, { text: "❌ فشل في تحميل القائمة." });
  }
}

export default { KlausBoJack, execute };