import fs from "fs";
import path from "path";
import axios from "axios";
import { generateWAMessageFromContent } from "@whiskeysockets/baileys";

const NovaUltra = {
  command: "شعر",
  description: "جلب أبيات شعرية من موقع الديوان",
  nova: "on"
};

const CACHE_MS = 3 * 60 * 1000;
let cache = {
  at: 0,
  text: null
};

function cleanText(str = "") {
  return str
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function pickImageBuffer() {
  try {
    const imagePath = path.join(process.cwd(), "nova", "image2.jpeg");
    if (fs.existsSync(imagePath)) return fs.readFileSync(imagePath);
  } catch {}
  return null;
}

async function sendFancyText(sock, jid, text, quotedMsg) {
  const imageBuffer = pickImageBuffer();

  const wm = generateWAMessageFromContent(
    jid,
    {
      extendedTextMessage: {
        text,
        contextInfo: {
          externalAdReply: {
            title: "𝐵𝑂𝐽𝐴𝐶𝐾 𝐿𝐼𝑇𝐸𝑅𝐴𝑇𝑈𝑅𝐸",
            body: "𝐾𝐿𝐴𝑈𝑆 𝑃𝑂𝐸𝑇𝑅𝑌 𝐸𝑁𝐺𝐼𝑁𝐸",
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true,
            thumbnail: imageBuffer || undefined
          }
        }
      }
    },
    {
      userJid: sock.user?.id,
      quoted: quotedMsg
    }
  );

  return sock.relayMessage(jid, wm.message, { messageId: wm.key.id });
}

function parseDiwanPoem(html) {
  const title = cleanText(
    html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || ""
  );

  const h3Lines = [...html.matchAll(/<h3[^>]*>([\s\S]*?)<\/h3>/gi)]
    .map(m => cleanText(m[1]))
    .filter(Boolean);

  const filtered = h3Lines.filter(t => {
    if (t.length < 2) return false;
    if (/^الديوان$/i.test(t)) return false;
    if (/^نبذة عن القصيدة$/i.test(t)) return false;
    if (/^المساهمات$/i.test(t)) return false;
    if (/^أضف شرح او معلومة$/i.test(t)) return false;
    if (/^أضف معلومة او شرح$/i.test(t)) return false;
    if (title && t === title) return false;
    return true;
  });

  return filtered;
}

async function getPoemFromDiwan() {
  const now = Date.now();
  if (cache.text && now - cache.at < CACHE_MS) return cache.text;

  const res = await axios.get("https://www.aldiwan.net/random", {
    timeout: 15000,
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
      "Accept-Language": "ar,en-US;q=0.9,en;q=0.8"
    }
  });

  const html = String(res.data || "");
  const lines = parseDiwanPoem(html);

  if (!lines.length) {
    throw new Error("لم يتم استخراج الأبيات");
  }

  const text = lines.join("\n");
  cache = { at: now, text };
  return text;
}

async function execute({ sock, msg }) {
  const chatId = msg.key.remoteJid;

  try {
    await sendFancyText(sock, chatId, "⏳ جاري جلب الأبيات...", msg);

    const poemText = await getPoemFromDiwan();

    await sendFancyText(sock, chatId, `📜 *الأبيات:*\n\n${poemText}`, msg);
  } catch (error) {
    await sock.sendMessage(
      chatId,
      { text: "⚠️ تعذر جلب الأبيات من الديوان الآن." },
      { quoted: msg }
    );
  }
}

export default { NovaUltra, execute };